# Manga AR — Android

هذا مشروع Android جاهز لفتح نسخة Manga AR الحالية داخل تطبيق Android.

## الرابط الحالي
https://3ca2b.netlify.app/

إذا تغير رابط Netlify، عدّل APP_URL داخل:
app/src/main/java/com/mangaar/app/MainActivity.java

## البناء
افتح المجلد في Android Studio، ثم Build > Generate App Bundle / APK.

هذا المشروع يحتاج Android SDK وGradle/Android Studio على جهاز البناء. لم يتم تضمين APK جاهز لأن بيئة الإنشاء الحالية لا تحتوي Android SDK/Gradle.
